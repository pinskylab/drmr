## -----------------------------------------------------------------------------
#| eval: false

## remotes::install_github("pinskylab/drmr")


## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data-load

## loads the data
data(sum_fl)

## computing density
sum_fl <- sum_fl |>
  mutate(dens = y / area_km2,
         .before = y)


## -----------------------------------------------------------------------------
#| label: data-split

## 5 years-ahead predictions
first_year_forecast <- max(sum_fl$year) - 5

first_id_forecast <-
  first_year_forecast - min(sum_fl$year) + 1

## splitting data
dat_test <- sum_fl |>
  filter(year >= first_year_forecast)

dat_train <- sum_fl |>
  filter(year < first_year_forecast)


## -----------------------------------------------------------------------------
#| label: simplest_fit

drm_1 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          n_ages = 8, ## number of age groups
          family = "lognormal2",
          seed = 2025,
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          chains = 4)


## -----------------------------------------------------------------------------
#| label: drm-2

drm_2 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          n_ages = 8, ## number of age groups
          family = "lognormal2",
          seed = 2025,
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          chains = 4,
          .toggles = list(time_ar = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: drm-2-summary

drm_2$draws$summary(variables = c("tau", "alpha"))


## -----------------------------------------------------------------------------
#| label: fmat

fmat <-
  system.file("fmat.rds", package = "drmr") |>
  readRDS()

years_all <- seq_len(NCOL(fmat))
years_train <- years_all[years_all < first_id_forecast]
years_test  <- years_all[years_all >= first_id_forecast]

f_train <- fmat[, years_train]
f_test  <- fmat[, years_test]


## -----------------------------------------------------------------------------
#| label: drm-3

drm_3 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          f_mort = f_train,
          n_ages = NROW(f_train), ## number of age groups
          family = "lognormal2",
          seed = 2025,
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          chains = 4,
          .toggles = list(time_ar = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: fig-map-adj
#| fig-cap: "Patches considered in this example."

map_name <- system.file("maps/sum_fl.shp", package = "drmr")

polygons <- st_read(map_name)

ggplot() +
  geom_sf(data = polygons,
          color = 1,
          fill = "gray70") +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: calc-adj

adj_mat <- gen_adj(st_buffer(st_geometry(polygons),
                             dist = 2500))

## row-standardized matrix
adj_mat <-
  t(apply(adj_mat, 1, \(x) x / (sum(x))))


## -----------------------------------------------------------------------------
#| label: adj-v2

n <- 13 ## number of patches
adj_mat2 <- diag(0, n)
adj_mat2[abs(row(adj_mat2) - col(adj_mat2)) == 1] <- 1

## row-standardizing
adj_mat2 <-
  t(apply(adj_mat2, 1, \(x) x / (sum(x))))


## -----------------------------------------------------------------------------
#| label: drm-4

drm_4 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          f_mort = f_train,
          n_ages = NROW(f_train), ## number of age groups
          family = "lognormal2",
          seed = 2025,
          adj_mat = adj_mat,
          ## ages_movement = 2,  ## age at which fish are able to move
          ages_movement = c(rep(0, 4), ## first four age-groups do not move
                            rep(1, 8), ## groups 5 to 12 are allowed to move
                            rep(0, 4)), ## last four age-groups do not move
          iter_sampling = 200, ## number of samples after warmup
          iter_warmup = 200, ## number of warmup samples
          parallel_chains = 4,
          chains = 4,
          .toggles = list(time_ar = 1,
                          movement = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: zeta-est

drm_4$draws$summary(variables = "zeta")


## -----------------------------------------------------------------------------
#| label: cov-centering

avgs <- c("stemp" = mean(dat_train$stemp),
          "btemp" = mean(dat_train$btemp))

min_year <- dat_train$year |> min()

dat_train <- dat_train |>
  mutate(stemp = stemp - avgs["stemp"],
         btemp = btemp - avgs["btemp"],
         time  = year - min_year)

dat_test <- dat_test |>
  mutate(stemp = stemp - avgs["stemp"],
         btemp = btemp - avgs["btemp"],
         time  = year - min_year)


## -----------------------------------------------------------------------------
#| label: fig-rel
#| fig-cap: "Available relationship between recruitment/survival and environmental factors."
#| echo: false
#| fig-subcap:
#|   - "Quadratic relationship 1"
#|   - "Quadratic relationship 2"
#|   - "log-linear relationship"
#| layout-ncol: 3

max_y <- function(x, .betas, type = "log", offset = 0) {
  .betas[1] <- .betas[1] - 2 * offset * .betas[2]
  max_x <- - .5  * .betas[1] / .betas[2]
  max_x2 <- max_x * max_x
  out <- as.numeric(cbind(1, max_x, max_x2) %*% .betas)
  if (type == "log") {
    return(exp(out))
  } else if (type == "logit") {
    return(expit(out))
  } else
    return(out)
}

t_max <- 2
b2 <- -0.25
b1 <- - 2 * t_max * b2
betas <- c(1, b1, b2)
my_df <- tibble(x = seq(from = 0, to = 20, length.out = 500)) |>
  mutate(x2 = x * x) |>
  mutate(ylin = as.numeric(cbind(1, x, x2) %*% betas)) |>
  mutate(ylog = exp(ylin))

## we can still get an analogous of "T_opt"
ggplot(data = my_df,
       aes(x = x, y = ylog)) +
  geom_line() +
  theme_bw()

t_max <- 11
b2 <- -0.05
b1 <- - 2 * t_max * b2
betas <- c(1, b1, b2)
my_df <- tibble(x = seq(from = 0, to = 20, length.out = 500)) |>
  mutate(x2 = x * x) |>
  mutate(ylin = as.numeric(cbind(1, x, x2) %*% betas)) |>
  mutate(ylog = exp(ylin))
## we can still get an analogous of "T_opt"
ggplot(data = my_df,
       aes(x = x, y = ylog)) +
  geom_line() +
  theme_bw()

betas <- c(.1, .25)
my_df <- tibble(x = seq(from = 0, to = 20, length.out = 500)) |>
  mutate(ylin = as.numeric(cbind(1, log(x)) %*% betas)) |>
  mutate(ylog = exp(ylin))

ggplot(data = my_df,
       aes(x = x, y = ylog)) +
  geom_line() +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: building-x

##--- formulas (will be helpful for forecasting as well) ----

## formula for the linear predictor of recruitmemt it defines a quadratic
## relationship between recruitment and surface temperature
form_r <- ~ 1 +
  stemp +
  I(stemp * stemp)

## formula for the linear predictor in the survival rates
form_m <- ~ 1 + btemp + I(btemp * btemp)

## formula for the linear predictor of observing a zero density
form_t <- ~ 1 +
  btemp +
  I(btemp * btemp) +
  stemp +
  I(stemp * stemp) +
  I(btemp * stemp)


## -----------------------------------------------------------------------------
#| label: drm-5

drm_5 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          f_mort = f_train,
          n_ages = NROW(f_train), ## number of age groups
          family = "lognormal2",
          seed = 2025,
          adj_mat = adj_mat,
          formula_zero = form_t,
          formula_rec = form_r,
          formula_surv = form_m,
          ages_movement = 3, ## age at which fish are able to move
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          init = "pathfinder",
          chains = 4,
          .toggles = list(time_ar = 1,
                          movement = 1,
                          est_mort = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: drm-6

drm_6 <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          f_mort = f_train,
          n_ages = NROW(f_train), ## number of age groups
          family = "gamma",
          seed = 2025,
          adj_mat = adj_mat,
          formula_zero = form_t,
          formula_rec = form_r,
          formula_surv = form_m,
          ages_movement = 3, ## age at which fish are able to move
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          init = "pathfinder",
          chains = 4,
          .toggles = list(time_ar = 1,
                          movement = 1,
                          est_mort = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: sdm-1

sdm_1 <-
  fit_sdm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch", ## vector of patches
          family = "lognormal2",
          seed = 2025,
          formula_zero = form_t,
          formula_dens = form_r,
          iter_sampling = 400, ## number of samples after warmup
          iter_warmup = 400, ## number of warmup samples
          parallel_chains = 4,
          init = "pathfinder",
          chains = 4,
          .toggles = list(time_ar = 1),
          .priors = list(pr_alpha_a = 5, pr_alpha_b = 5))


## -----------------------------------------------------------------------------
#| label: loo-compare

all_loos <-
  list("DRM 1" = drm_1$draws$loo(),
       "DRM 2" = drm_2$draws$loo(),
       "DRM 3" = drm_3$draws$loo(),
       "DRM 4" = drm_4$draws$loo(),
       "DRM 5" = drm_5$draws$loo(),
       "DRM 6" = drm_6$draws$loo(),
       "SDM 1" = sdm_1$draws$loo())


loo::loo_compare(all_loos)


## -----------------------------------------------------------------------------
#| label: fig-drm6_1

color_scheme_set("mix-red-blue")

viz_pars <-
  c("tau[1]",
    "alpha[1]",
    "phi[1]")

mcmc_combo(drm_6$draws$draws(variables = viz_pars),
           combo = c("trace", "dens_overlay"),
           facet_args = list(labeller = label_parsed))


## -----------------------------------------------------------------------------
#| label: fig-drm6_2
#| fig-cap: "Regression coefficients for recruitment."

mcmc_combo(drm_6$draws$draws(variables = "coef_r"),
           combo = c("trace", "dens_overlay"))


## -----------------------------------------------------------------------------
#| label: fig-drm6_3
#| fig-cap: "Regression coefficients for survival."

mcmc_combo(drm_6$draws$draws(variables = "coef_m"),
           combo = c("trace", "dens_overlay"))


## -----------------------------------------------------------------------------
#| label: fig-drm6_4
#| fig-cap: "Regression coefficients for the probability of observing 0 density."
#| fig-height: 9

mcmc_combo(drm_6$draws$draws(variables = "coef_t"),
           combo = c("trace", "dens_overlay"))


## -----------------------------------------------------------------------------
#| label: fig-drm6_pp
#| fig-cap: "Posterior predictive check."

y_pp <-
  drm_6$draws$draws(variables = "y_pp",
                    format = "matrix")

ppc_dens_overlay(drm_6$data$y,
                 y_pp[sample(seq_len(NROW(y_pp)),
                             size = 200), ])


## -----------------------------------------------------------------------------
#| label: fig-sdm_1

viz_pars <-
  c("tau[1]",
    "alpha[1]",
    "phi[1]")

mcmc_combo(sdm_1$draws$draws(variables = viz_pars),
           combo = c("trace", "dens_overlay"),
           facet_args = list(labeller = label_parsed))


## -----------------------------------------------------------------------------
#| label: fig-sdm_2
#| fig-cap: "Regression coefficients for positive density."

mcmc_combo(sdm_1$draws$draws(variables = "coef_r"),
           combo = c("trace", "dens_overlay"))


## -----------------------------------------------------------------------------
#| label: fig-sdm_3
#| fig-cap: "Regression coefficients for the probability of observing 0 density."
#| fig-height: 9

mcmc_combo(sdm_1$draws$draws(variables = "coef_t"),
           combo = c("trace", "dens_overlay"))


## -----------------------------------------------------------------------------
#| label: fig-sdm_pp
#| fig-cap: "Posterior predictive check."

y_pp <-
  sdm_1$draws$draws(variables = "y_pp",
                    format = "matrix")

ppc_dens_overlay(sdm_1$data$y,
                 y_pp[sample(seq_len(NROW(y_pp)),
                             size = 200), ])


## -----------------------------------------------------------------------------
#| label: forecast-1

x_tt <- model.matrix(form_t,
                     data = dat_test)
x_mt <- model.matrix(form_m,
                     data = dat_test)
x_rt <- model.matrix(form_r,
                     data = dat_test)

x_mpast <-
  model.matrix(form_m,
               data = filter(dat_train, year == max(year)))

forecast_drm_6 <- predict_drm(drm = drm_6$draws,
                              drm_data = drm_6$data,
                              ntime_for =
                                length(unique(dat_test$year)),
                              x_tt = x_tt,
                              x_rt = x_rt,
                              x_mt = x_mt,
                              x_mpast = x_mpast,
                              f_test = f_test[, -1],
                              seed = 125,
                              cores = 4)
##--- * SDM ----

fitted_params <-
  sdm_1$draws(variables = c("coef_t", "coef_r",
                            "z_t",
                            "alpha", "tau",
                            "phi"))

forecast_sdm_1 <-
  predict_sdm(sdm = sdm_1$draws,
              sdm_data = sdm_1$data,
              ntime_for =
                length(unique(dat_test$year)),
              z_t = x_tt,
              x_t = x_rt,
              time_for = dat_test$year,
              seed = 125,
              cores = 4)


## -----------------------------------------------------------------------------
#| label: fig-forecast_mu
#| fig-cap: Forecast DRM.

mu_drm <-
  forecast_drm_6$draws(variables = "mu_proj",
                     format = "draws_df") |>
  tidyr::pivot_longer(cols = starts_with("mu_proj"),
                      names_to = "pair",
                      values_to = "expected") |>
  group_by(pair) |>
  summarise(ll = quantile(expected, probs = .05),
            l = quantile(expected, probs = .1),
            m = median(expected),
            u = quantile(expected, probs = .9),
            uu = quantile(expected, probs = .95)) |>
  ungroup() |>
  mutate(pair = gsub("\\D", "", pair)) |>
  mutate(pair = as.integer(pair)) |>
  arrange(pair)

mu_drm <-
  dat_test |>
  select(dens, lat_floor, patch, year) |>
  mutate(pair = row_number()) |>
  left_join(mu_drm, by = "pair") |>
  mutate(model = "DRM")

mu_sdm <-
  forecast_sdm_1$draws(variables = "mu_proj",
                     format = "draws_df") |>
  tidyr::pivot_longer(cols = starts_with("mu_proj"),
                      names_to = "pair",
                      values_to = "expected") |>
  group_by(pair) |>
  summarise(ll = quantile(expected, probs = .05),
            l = quantile(expected, probs = .1),
            m = median(expected),
            u = quantile(expected, probs = .9),
            uu = quantile(expected, probs = .95)) |>
  ungroup() |>
  mutate(pair = gsub("\\D", "", pair)) |>
  mutate(pair = as.integer(pair)) |>
  arrange(pair)

mu_sdm <-
  dat_test |>
  select(dens, lat_floor, patch, year) |>
  mutate(pair = row_number()) |>
  left_join(mu_sdm, by = "pair") |>
  mutate(model = "SDM")

mu_proj <- bind_rows(mu_drm, mu_sdm)

my_color <- "#0465cf"
ggplot(data = mu_proj,
         aes(x = year,
             y = m)) +
  geom_ribbon(aes(ymin = ll, ymax = uu),
              fill = my_color,
              alpha = .4) +
  geom_ribbon(aes(ymin = l, ymax = u),
              fill = my_color,
              alpha = .4) +
  geom_line() +
  geom_point() +
  theme_bw() +
  facet_grid(model ~ patch,
             scales = "free_y") +
  labs(y = expression(mu),
       x = "Year")


## -----------------------------------------------------------------------------
#| label: fig-forecast_y

y_drm <-
  forecast_drm_6$draws(variables = "y_proj",
                       format = "draws_df") |>
  tidyr::pivot_longer(cols = starts_with("y_proj"),
                      names_to = "pair",
                      values_to = "expected") |>
  group_by(pair) |>
  summarise(ll = quantile(expected, probs = .05),
            l = quantile(expected, probs = .1),
            m = median(expected),
            u = quantile(expected, probs = .9),
            uu = quantile(expected, probs = .95)) |>
  ungroup() |>
  mutate(pair = gsub("\\D", "", pair)) |>
  mutate(pair = as.integer(pair)) |>
  arrange(pair)

y_drm <-
  dat_test |>
  select(dens, lat_floor, patch, year) |>
  mutate(pair = row_number()) |>
  left_join(y_drm, by = "pair") |>
  mutate(model = "DRM")

y_sdm <-
  forecast_sdm_1$draws(variables = "y_proj",
                       format = "draws_df") |>
  tidyr::pivot_longer(cols = starts_with("y_proj"),
                      names_to = "pair",
                      values_to = "expected") |>
  group_by(pair) |>
  summarise(ll = quantile(expected, probs = .05),
            l = quantile(expected, probs = .1),
            m = median(expected),
            u = quantile(expected, probs = .9),
            uu = quantile(expected, probs = .95)) |>
  ungroup() |>
  mutate(pair = gsub("\\D", "", pair)) |>
  mutate(pair = as.integer(pair)) |>
  arrange(pair)

y_sdm <-
  dat_test |>
  select(dens, lat_floor, patch, year) |>
  mutate(pair = row_number()) |>
  left_join(y_sdm, by = "pair") |>
  mutate(model = "SDM")

y_proj <- bind_rows(y_drm, y_sdm)

ggplot(data = y_proj,
         aes(x = year,
             y = patch,
             fill = m)) +
  geom_tile() +
  scale_fill_viridis_c(option = "H") +
  scale_y_continuous(breaks = 1:10) +
  facet_wrap(~ model) +
  theme_bw()

my_color <- "#0465cf"
ggplot(data = y_proj,
         aes(x = year,
             y = m)) +
  geom_ribbon(aes(ymin = ll, ymax = uu),
              fill = my_color,
              alpha = .4) +
  geom_ribbon(aes(ymin = l, ymax = u),
              fill = my_color,
              alpha = .4) +
  geom_line() +
  geom_point() +
  geom_point(aes(x = year, y = dens),
             inherit.aes = FALSE,
             color = 2) +
  facet_wrap(patch ~ model,
             scales = "free_y") +
  theme_bw() +
  facet_grid(model ~ patch,
             scales = "free_y") +
  labs(y = expression(mu),
       x = "Year")


## -----------------------------------------------------------------------------
#| label: tbl-assessment
#| tbl-cap: Forecasting assessment.

y_proj |>
  mutate(bias = dens - m) |>
  mutate(rmse = bias * bias) |>
  mutate(abias = abs(bias)) |>
  mutate(is1 = int_score(dens, l = ll, u = uu, alpha = .1)) |>
  mutate(is2 = int_score(dens, l = l, u = u, alpha = .2)) |>
  mutate(cvg1 = between(dens, ll, uu)) |>
  mutate(cvg2 = between(dens, l, u)) |>
  group_by(model) |>
  summarise(across(bias:cvg2, mean)) |>
  ungroup() |>
  rename_all(toupper) |>
  rename("Model" = "MODEL",
         "IS (90%)" = "IS1",
         "IS (80%)" = "IS2",
         "PIC (90%)" = "CVG1",
         "PIC (80%)" = "CVG2")


## -----------------------------------------------------------------------------
#| label: fig-centroids
#| fig-cap: Density weighted centroids estimated by the DRM and SDM. The red vertical line indicates where the "forecast" period starts.

centroids_compiled <-
  instantiate::stan_package_model(name = "centroid",
                                  package = "drmr")

centroid_drm <-
  centroids_compiled$
  generate_quantities(fitted_params =
                        posterior::bind_draws(
                                       drm_6$draws$draws(variables = "y_pp"),
                                       forecast_drm_6$draws(variables = "y_proj")
                                       ),
                      data = list(
                          N1 = nrow(dat_train),
                          N2 = nrow(dat_test),
                          n_c = 1,
                          coords =
                            matrix(c(dat_train$lat_floor,
                                     dat_test$lat_floor),
                                   ncol = 1),
                          n_t = length(unique(c(dat_train$year,
                                                dat_test$year)))
                      ),
                      seed = 2025,
                      parallel_chains = 4)

centroid_sdm <-
  centroids_compiled$
  generate_quantities(fitted_params =
                        posterior::bind_draws(
                                       sdm_1$draws$draws(variables = "y_pp"),
                                       forecast_sdm_1$draws(variables = "y_proj")
                                       ),
                      data = list(
                          N1 = nrow(dat_train),
                          N2 = nrow(dat_test),
                          n_c = 1,
                          coords =
                            matrix(c(dat_train$lat_floor,
                                     dat_test$lat_floor),
                                   ncol = 1),
                          n_t = length(unique(c(dat_train$year,
                                                dat_test$year)))
                      ),
                      seed = 2025,
                      parallel_chains = 4)


centroid_all <-
  bind_rows(
      centroid_drm$draws() |>
      bayesplot::mcmc_intervals_data() |>
      mutate(type = gsub("[[:digit:][:punct:]]", "", parameter),
             .before = parameter) |>
      mutate(parameter = gsub("\\D", "", parameter)) |>
      mutate(parameter = ifelse(nchar(parameter) == 2,
                                substr(parameter, 1, 1),
                                substr(parameter, 1, 2))) |>
      mutate(year = as.integer(parameter) + min(dat_train$year),
             .before = parameter,
             model = "DRM"),
      centroid_sdm$draws() |>
      bayesplot::mcmc_intervals_data() |>
      mutate(type = gsub("[[:digit:][:punct:]]", "", parameter),
             .before = parameter) |>
      mutate(parameter = gsub("\\D", "", parameter)) |>
      mutate(parameter = ifelse(nchar(parameter) == 2,
                                substr(parameter, 1, 1),
                                substr(parameter, 1, 2))) |>
      mutate(year = as.integer(parameter) +  min(dat_train$year),
             .before = parameter,
             model = "SDM")
  )

ggplot(data = filter(centroid_all,
                     type == "centroid"),
         aes(x = year,
             y = m)) +
  geom_ribbon(aes(ymin = ll, ymax = hh),
              fill = my_color,
              alpha = .4) +
  geom_ribbon(aes(ymin = l, ymax = h),
              fill = my_color,
              alpha = .4) +
  geom_line() +
  geom_point() +
  geom_vline(xintercept = first_year_forecast,
             col = 2, lty = 2,
             lwd = 1.2) +
  facet_wrap( ~ model) +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: load-sdm

sdm_compiled <-
  instantiate::stan_package_model(name = "sdm",
                                  package = "drmr")


## -----------------------------------------------------------------------------
#| label: load-drm

drm_compiled <-
  instantiate::stan_package_model(name = "drm",
                                  package = "drmr")


## -----------------------------------------------------------------------------
#| label: load-forecasts

forecast_sdm <-
  instantiate::stan_package_model(name = "forecast_sdm",
                                  package = "drmr")

forecast_drm <-
  instantiate::stan_package_model(name = "forecast",
                                  package = "drmr")


## -----------------------------------------------------------------------------
#| label: load-centroids

centroids_compiled <-
  instantiate::stan_package_model(name = "centroid",
                                  package = "drmr")

